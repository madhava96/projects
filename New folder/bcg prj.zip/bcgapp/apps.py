from django.apps import AppConfig


class BcgappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bcgapp'
